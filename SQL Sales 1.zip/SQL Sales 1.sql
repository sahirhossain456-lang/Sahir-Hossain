create database ECommerce

use ECommerce

select* from sales
select * from [dbo].[Walmart Sales]


select Product_ID, Sale_Date, Product_Category, Unit_Cost, Unit_Price
from sales 
where Product_Category = 'Furniture'
order by Sale_Date

select Product_Category, SUM(Quantity_Sold * Unit_Price) AS Total_Sales, AVG(Quantity_Sold * Unit_Price) AS AVG_Sales
from sales
group by Product_Category

select sales.Product_ID, sales.Sales_Rep, sales.Region, sales.Unit_Cost, sales.Unit_Price, [Walmart Sales].City
from sales 
Inner Join [Walmart Sales]  ON sales.Region = [Walmart Sales].City


select sales.Product_ID, SUM(Sales.Quantity_Sold * Sales.Unit_Price) AS Total_Sales
from sales 
group by sales.Product_ID

create view Customer AS select Product_ID, Sales_Rep  from sales

create Index idx_Sales_Product_ID ON Sales(Product_ID)
create Index idx_Sales_Region ON Sales(Region)









